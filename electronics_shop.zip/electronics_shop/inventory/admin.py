from django.contrib import admin
from .models import Product

# Register your models here.

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'category', 'brand', 'get_price', 'stock')
    list_filter = ('category', 'brand')
    search_fields = ('name', 'brand', 'model_number')
    ordering = ('category', 'brand', 'name')

    def get_price(self, obj):
        return f'₹{obj.price}'
    get_price.short_description = 'Price (₹)'
