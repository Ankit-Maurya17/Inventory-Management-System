from django.urls import path
from . import views

urlpatterns = [
    path('', views.ProductListView.as_view(), name='product-list'),
    path('create/', views.ProductCreateView.as_view(), name='product-create'),
    path('update/<int:pk>/', views.ProductUpdateView.as_view(), name='product-update'),
    path('delete/<int:pk>/', views.ProductDeleteView.as_view(), name='product-delete'),
    path('product/<int:pk>/', views.ProductDetailView.as_view(), name='product-detail'),
    path('product/<int:pk>/rate/', views.add_rating, name='add-rating'),
    path('product/<int:pk>/buy/', views.create_order, name='create-order'),
    path('product/<int:pk>/check-delivery/', views.check_delivery, name='check-delivery'),
    path('order/<int:order_id>/confirmation/', views.order_confirmation, name='order-confirmation'),
]
