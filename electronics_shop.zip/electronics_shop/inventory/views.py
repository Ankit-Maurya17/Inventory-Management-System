from django.shortcuts import render, redirect, get_object_or_404
from django.views.generic import ListView, CreateView, UpdateView, DeleteView, DetailView
from django.urls import reverse_lazy
from django.contrib import messages
from django.views.decorators.http import require_POST
from django.http import JsonResponse
from django.db.models import Q
from .models import Product, Rating, Order, DeliveryPincode

# Create your views here.

class ProductListView(ListView):
    model = Product
    template_name = 'inventory/product_list.html'
    context_object_name = 'products'

    def get_queryset(self):
        queryset = Product.objects.all()
        # Handle search
        search_query = self.request.GET.get('search')
        category = self.request.GET.get('category')
        
        if search_query:
            queryset = queryset.filter(
                Q(name__icontains=search_query) |
                Q(brand__icontains=search_query) |
                Q(description__icontains=search_query)
            )
        if category:
            queryset = queryset.filter(category=category)
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['search_query'] = self.request.GET.get('search', '')
        return context

class ProductDetailView(DetailView):
    model = Product
    template_name = 'inventory/product_detail.html'
    context_object_name = 'product'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['ratings'] = self.object.ratings.all().order_by('-created_at')
        context['similar_products'] = self.object.get_similar_products()
        return context

class ProductCreateView(CreateView):
    model = Product
    template_name = 'inventory/product_form.html'
    fields = ['name', 'category', 'brand', 'model_number', 'price', 'stock', 'description', 'image']
    success_url = reverse_lazy('product-list')

    def form_valid(self, form):
        messages.success(self.request, 'Product added successfully!')
        return super().form_valid(form)

class ProductUpdateView(UpdateView):
    model = Product
    template_name = 'inventory/product_form.html'
    fields = ['name', 'category', 'brand', 'model_number', 'price', 'stock', 'description', 'image']
    success_url = reverse_lazy('product-list')

    def form_valid(self, form):
        messages.success(self.request, 'Product updated successfully!')
        return super().form_valid(form)

class ProductDeleteView(DeleteView):
    model = Product
    template_name = 'inventory/product_confirm_delete.html'
    success_url = reverse_lazy('product-list')

    def delete(self, request, *args, **kwargs):
        messages.success(self.request, 'Product deleted successfully!')
        return super().delete(request, *args, **kwargs)

@require_POST
def add_rating(request, pk):
    product = get_object_or_404(Product, pk=pk)
    rating_value = int(request.POST.get('rating'))
    customer_name = request.POST.get('customer_name')
    customer_email = request.POST.get('customer_email', '')
    comment = request.POST.get('comment', '')
    
    if not customer_name:
        messages.error(request, 'Please provide your name!')
        return redirect('product-detail', pk=pk)
    
    Rating.objects.create(
        product=product,
        rating=rating_value,
        customer_name=customer_name,
        customer_email=customer_email,
        comment=comment
    )
    
    messages.success(request, 'Thank you for your review!')
    return redirect('product-detail', pk=pk)

@require_POST
def check_delivery(request, pk):
    pincode = request.POST.get('pincode')
    if not pincode or not pincode.isdigit() or len(pincode) != 6:
        return JsonResponse({
            'status': 'error',
            'message': 'Please enter a valid 6-digit pincode'
        })
    
    try:
        delivery_info = DeliveryPincode.objects.get(pincode=pincode)
        if delivery_info.is_serviceable:
            return JsonResponse({
                'status': 'success',
                'message': f'Delivery available in {delivery_info.city}, {delivery_info.state}',
                'delivery_days': delivery_info.delivery_days
            })
        else:
            return JsonResponse({
                'status': 'error',
                'message': 'Sorry, delivery is not available in your area'
            })
    except DeliveryPincode.DoesNotExist:
        return JsonResponse({
            'status': 'error',
            'message': 'Sorry, delivery is not available in your area'
        })

def create_order(request, pk):
    product = get_object_or_404(Product, pk=pk)
    if request.method == 'POST':
        payment_method = request.POST.get('payment_method')
        quantity = int(request.POST.get('quantity', 1))
        emi_months = request.POST.get('emi_months')
        
        if emi_months:
            emi_months = int(emi_months)
        
        order = Order.objects.create(
            product=product,
            quantity=quantity,
            payment_method=payment_method,
            emi_months=emi_months if payment_method == 'emi' else None
        )
        
        messages.success(request, 'Order placed successfully!')
        return redirect('order-confirmation', order_id=order.id)
    
    return render(request, 'inventory/order_form.html', {
        'product': product,
        'emi_choices': Order.EMI_CHOICES,
        'payment_choices': Order.PAYMENT_CHOICES
    })

def order_confirmation(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    return render(request, 'inventory/order_confirmation.html', {'order': order})
