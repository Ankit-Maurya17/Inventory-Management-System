from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator

class DeliveryPincode(models.Model):
    pincode = models.CharField(max_length=6)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    delivery_days = models.IntegerField(default=5)
    is_serviceable = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.pincode} - {self.city}, {self.state}"

class Product(models.Model):
    CATEGORY_CHOICES = [
        ('mobile', 'Mobile'),
        ('laptop', 'Laptop'),
        ('smartwatch', 'Smart Watch'),
    ]
    
    name = models.CharField(max_length=200)
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES)
    brand = models.CharField(max_length=100)
    model_number = models.CharField(max_length=100)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    stock = models.IntegerField()
    description = models.TextField()
    image = models.ImageField(upload_to='product_images/', null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    average_rating = models.DecimalField(max_digits=3, decimal_places=2, default=0)
    total_ratings = models.IntegerField(default=0)

    def __str__(self):
        return f"{self.brand} {self.name} ({self.category})"

    def calculate_emi(self, months):
        return self.price / months

    def get_similar_products(self):
        try:
            similar_products = Product.objects.filter(
                category=self.category
            ).exclude(id=self.id)[:4]
            return similar_products
        except Exception as e:
            # Log the error or handle it as needed
            return []  # Return an empty list if there's an error

class Rating(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='ratings')
    customer_name = models.CharField(max_length=100, default='Anonymous')
    customer_email = models.EmailField(blank=True)
    rating = models.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)])
    comment = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        product = self.product
        avg = product.ratings.aggregate(models.Avg('rating'))['rating__avg']
        total = product.ratings.count()
        product.average_rating = round(avg, 2) if avg else 0
        product.total_ratings = total
        product.save()

    def __str__(self):
        return f"{self.customer_name}'s review of {self.product.name}"

class Order(models.Model):
    PAYMENT_CHOICES = [
        ('cod', 'Cash on Delivery'),
        ('card', 'Credit/Debit Card'),
        ('upi', 'UPI'),
        ('emi', 'EMI'),
    ]
    EMI_CHOICES = [
        (3, '3 Months'),
        (6, '6 Months'),
        (9, '9 Months'),
        (12, '12 Months'),
    ]
    
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1)
    payment_method = models.CharField(max_length=10, choices=PAYMENT_CHOICES)
    emi_months = models.IntegerField(choices=EMI_CHOICES, null=True, blank=True)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    emi_amount = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        self.total_amount = self.product.price * self.quantity
        if self.payment_method == 'emi' and self.emi_months:
            self.emi_amount = self.total_amount / self.emi_months
        super().save(*args, **kwargs)
